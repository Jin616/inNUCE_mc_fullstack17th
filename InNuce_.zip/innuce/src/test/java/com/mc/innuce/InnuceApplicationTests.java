package com.mc.innuce;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InnuceApplicationTests {

}
