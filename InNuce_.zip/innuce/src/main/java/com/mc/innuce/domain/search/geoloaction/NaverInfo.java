package com.mc.innuce.domain.search.geoloaction;

public class NaverInfo {
	//geolocation
	public static final String geo_Access_Key_ID = "8EDDD6CD6BBFCD6F2026";
	public static final String geo_Secret_Key = "71B770310245A9EE0DFE62B3BE74F51CF64A5A67";

	//chatbot
	public static final String chatbotApiUrl = "https://gnpyk13cj1.apigw.ntruss.com/custom/v1/13398/3100610e7c62a184fe22dfd4619d5f02de3d80fc48a5abad4bef07d3ae7bb16c";
	public static final String chatbot_Secret_Key = "c3dLc2JHc25jWXZhRnl2b0FtbVVZSVpIVE5UWlpiV20=";
}
