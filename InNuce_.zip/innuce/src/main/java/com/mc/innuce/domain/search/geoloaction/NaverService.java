package com.mc.innuce.domain.search.geoloaction;

// ai 서비스가 필요로 하는 매개변수 1개

public interface NaverService {
	String test(String filename);
}
